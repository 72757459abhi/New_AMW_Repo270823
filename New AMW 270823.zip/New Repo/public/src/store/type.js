const Type={
    "LOGIN":"LOGIN",
    "TOKEN": "TOKEN",
     "USERDETAILS": "USERDETAILS"
}

export default Type